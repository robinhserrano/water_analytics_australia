part of 'sales_cubit.dart';

abstract class SalesCubitState extends Equatable {
  const SalesCubitState();

  @override
  List<Object> get props => [];
}

class SalesInitial extends SalesCubitState {
  const SalesInitial();
}

class SalesStateLoading extends SalesCubitState {
  const SalesStateLoading();
}

class SalesStateLoaded extends SalesCubitState {
  const SalesStateLoaded(this.records);
  final List<SalesOrder> records;

  @override
  List<Object> get props => [];
}

class SalesStateError extends SalesCubitState {
  const SalesStateError({required this.message});
  final String message;
  @override
  List<Object> get props => [message];
}
